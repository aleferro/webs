<br><br>
<footer class="main-footer bg-secondary fixed-bottom">
    <div class="container-fluid">
      <div class="pull-right hidden-xs">
        <h6>All rights reserved</h6>
      </div>
      <h6>Copyright &copy; 2020 Brought to You By <a href="https://www.github.com/aleferro">aleferro</a></h6>
    </div>
</footer>