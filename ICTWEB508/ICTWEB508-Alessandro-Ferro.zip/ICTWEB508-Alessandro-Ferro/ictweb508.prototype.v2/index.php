<?php
include "inc/header.php";
include "inc/navbar.php";
?>
<img src="img/banner.jpg" class="img-fluid mx-auto d-block" alt="Image of a face on a pot">
<h1 class="d-flex justify-content-center display-5">Special Offers</h1>
<div class="d-flex justify-content-center">
  <div class="p-2"><img src="img/pottery1.jpg" class="img-fluid rounded mx-auto d-block w-75" alt="Image of pottery"></div>
  <div class="p-2"><img src="img/pottery1.jpg" class="img-fluid rounded mx-auto d-block w-75" alt="Image of pottery"></div>
</div>
<div class="d-flex flex-row justify-content-center">
  <div class="p-2"><img src="img/pottery1.jpg" class=" img-fluid rounded mx-auto d-block w-75" alt="Image of pottery"></div>
  <div class="p-2"><img src="img/pottery1.jpg" class="img-fluid rounded mx-auto d-block w-75" alt="Image of pottery"></div>
</div>
<br>
<h3 class="d-flex justify-content-center">Upcoming Exhibitions</h3>
<br>
<div class="d-flex">
  <div class="float-left"><img src="img/banner.jpg" class="img-fluid mx-auto d-block" alt="Image of a face on a pot"></div>
</div>
<?php
include "inc/footer.php";
?>