<footer class="footer fixed-bottom">
<br>
  <div class="container-fluid bg-light">
    <div class="row" style="margin-top:4%;">
      <div class="col-sm-4 text-center text-muted">Terms and conditions</div>
      <div class="col-sm-4 text-center text-muted">Bazaar Ceramics pty ltd</div>
      <div class="col-sm-4 text-center text-muted">All rights reserved</div>
    </div><br>
    <div class="row">
      <div class="col-sm-4 text-center text-muted"></div>
      <div class="col-sm-4 text-center text-info">Developed by AleFerro</div>
      <div class="col-sm-4 text-center text-muted"></div>
    </div>
  </div>
</footer>

<!-- Bootstrap Bundle with Popper -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/js/bootstrap.bundle.min.js" integrity="sha384-b5kHyXgcpbZJO/tY9Ul7kGkf1S0CWuKcCD38l8YkeH8z8QjE0GmW1gYU5S9FOnJ0" crossorigin="anonymous"></script>

<!-- javascript -->
<script src="js/scripts.js"></script>
</body>
</html>